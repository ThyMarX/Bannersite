(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x600_atlas_P_", frames: [[0,0,300,600]]},
		{name:"300x600_atlas_P_2", frames: [[0,102,120,40],[0,0,160,100]]}
];


// symbols:



(lib.button = function() {
	this.initialize(ss["300x600_atlas_P_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.pris = function() {
	this.initialize(ss["300x600_atlas_P_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Q8_LowRisQ_Privat160x600_Q8_LowRisQ_Privat = function() {
	this.initialize(ss["300x600_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Tween9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.button();
	this.instance.parent = this;
	this.instance.setTransform(-60,-20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-60,-20,120,40);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgbA9QgBAAAAAAQgBgBAAAAQAAAAgBgBQAAAAAAgBIABgBIACgGQAAgBAAAAQABgBAAAAQAAAAABAAQAAAAAAgBIACABQANAGAJAAQAOgBAHgHQAFgIAAgQIAAgIQgEAFgIADQgIADgGAAQgTAAgLgNQgJgNAAgTQAAgUAKgNQAMgPASAAQARAAAJALIAAgFQAAgEAEAAIAIAAQADAAAAAEIAABSQAAAvgpAAQgOAAgNgHgAgRgrQgGAJAAAOQAAAOAFAIQAHALAMAAQAGAAAIgDQAHgEADgFIAAgqQgDgFgGgEQgHgEgHAAQgMAAgHALg");
	this.shape.setTransform(54.425,48.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAaAvQgDAAAAgEIAAg0QAAgMgEgFQgFgHgKABQgNAAgMALIAABAQAAAEgEAAIgJAAQgEAAAAgEIAAhTQAAgEAEAAIAIAAQAEAAAAAEIAAAFQAOgLAQAAQAfAAAAAiIAAA3QAAAEgEAAg");
	this.shape_1.setTransform(44.975,46.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgDA+QgEAAAAgEIAAhTQAAgEAEAAIAHAAQAEAAAAAEIAABTQAAAEgEAAgAgGgtQgDgCAAgEQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAEgDACQgDADgEAAQgDAAgDgDg");
	this.shape_2.setTransform(38.1,45.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgSAvQgEAAAAgEIAAhTQAAgEAEAAIAIAAQAEAAAAAEIAAAGQAIgMANAAIAGAAQAAABABAAQAAAAAAABQABAAAAABQAAAAgBABIgBAIQAAABAAAAQAAABgBAAQAAAAAAAAQgBABAAAAIgGgBQgLAAgHAMIAAA/QAAAEgEAAg");
	this.shape_3.setTransform(33.905,46.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAVBEQgEAAgCgDIgcgrIgEAEIAAAmQAAAEgEAAIgJAAQgDAAAAgEIAAh9QAAgDADgBIAKgCQADAAAAAEIAABMIAdgiQAAAAABgBQAAAAABgBQAAAAABAAQAAAAABAAIAMAAQAAAAABAAQAAAAAAAAQAAAAAAABQABAAAAAAIgBACIgdAhIAhAyQAEAFgGAAg");
	this.shape_4.setTransform(27.1931,44.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgDA+QgEAAAAgEIAAhTQAAgEAEAAIAIAAQADAAAAAEIAABTQAAAEgDAAgAgGgtQgDgCAAgEQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAEgDACQgDADgEAAQgDAAgDgDg");
	this.shape_5.setTransform(20.75,45.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcAqQgBAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBIACgGQAAgBABgBQAAAAABAAQAAgBAAAAQABAAABABQANAFAJAAQAIAAAFgDQAFgEAAgHQAAgJgOgGIgMgEQgUgIAAgPQAAgNAKgGQAJgHAMAAQANAAAMAGIACACIgBABIgCAHQAAAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgCAAQgJgFgKAAQgHAAgEAEQgEADAAAFQAAAIAMAFIAOAHQASAGAAARQAAAMgJAJQgKAHgOAAQgNAAgNgGg");
	this.shape_6.setTransform(15.3357,46.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgSAvQgEAAAAgEIAAhTQAAgEAEAAIAIAAQAEAAAAAEIAAAGQAIgMANAAIAGAAQAAABABAAQAAAAAAABQABAAAAABQAAAAgBABIgBAIQAAABAAAAQAAABgBAAQAAAAAAAAQgBABAAAAIgGgBQgLAAgHAMIAAA/QAAAEgEAAg");
	this.shape_7.setTransform(9.655,46.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AggAiQgKgNAAgVQAAgUALgNQAMgOAUAAQAVAAALAOQAKAMAAAVQAAAVgLANQgMAOgUAAQgVAAgLgOgAgUgXQgFAJAAAOQAAAOAFAKQAHALANAAQANAAAIgLQAGgJAAgPQAAgOgGgJQgHgMgOAAQgNAAgHAMg");
	this.shape_8.setTransform(1.625,46.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgOBEQgDAAAAgDIAAhMIgLAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBAAAAIAAgHQAAAAAAgBQAAAAABgBQAAAAABAAQAAAAABAAIALAAIAAgEIABgPQADgbAZABQAKAAAIACQADACgBAEIgBAFQgBABAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAIgCAAQgHgCgGgBQgJAAgEAHQgCAFAAAMIAAAJIAWAAQABAAAAAAQABAAAAAAQABAAAAABQAAAAAAABIAAAHQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAIgWAAIAABMQAAADgEAAg");
	this.shape_9.setTransform(-6.0125,44.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgcAqQgBAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBIACgGQAAgBABgBQAAAAABAAQAAgBAAAAQABAAABABQANAFAJAAQAIAAAFgDQAFgEAAgHQAAgJgOgGIgMgEQgUgIAAgPQAAgNAKgGQAJgHAMAAQANAAAMAGIACACIgBABIgCAHQAAAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgCAAQgJgFgKAAQgHAAgEAEQgEADAAAFQAAAIAMAFIAOAHQASAGAAARQAAAMgJAJQgKAHgOAAQgNAAgNgGg");
	this.shape_10.setTransform(-12.7643,46.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgSAvQgEAAAAgEIAAhTQAAgEAEAAIAIAAQAEAAAAAEIAAAGQAIgMANAAIAGAAQAAABABAAQAAAAAAABQABAAAAABQAAAAgBABIgBAIQAAABAAAAQAAABgBAAQAAAAAAAAQgBABAAAAIgGgBQgLAAgHAMIAAA/QAAAEgEAAg");
	this.shape_11.setTransform(-18.445,46.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgjAiQgJgNAAgTQAAgWAMgOQALgNASAAQAPAAAJALIAAgFQAAgBAAgBQABgBAAAAQABgBAAAAQABAAABAAIAIAAQAEAAAAAEIAABBQAAAHABACQAAAAAAABQABAAAAAAQAAAAABAAQAAAAABAAIABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABIAAAGQAAABAAABQgBAAAAAAQAAABgBAAQAAAAgBAAIgIAAQgGAAgDgEQgDgEAAgGIgBAAQgDAGgIAFQgJAFgHAAQgTAAgKgOgAgUgYQgHAJAAAPQAAAQAHAJQAGAKAKgBQAIAAAHgFQAHgGADgIIAAgkQgEgFgGgEQgGgEgGAAQgMAAgHAKg");
	this.shape_12.setTransform(-26.475,46.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgDAuQgEAAgBgDIgfhUQAAgBAAgBQAAgBAAAAQAAgBABAAQABAAAAAAIALAAQAEAAAAADIASAyIAFATIAGgSIARgyQABgEAEAAIAJAAQAAAAABAAQABAAAAABQAAAAAAABQAAABAAABIgfBUQgCADgDAAg");
	this.shape_13.setTransform(-35.45,46.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgcAqQgBAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBIACgGQAAgBABgBQAAAAABAAQAAgBAAAAQABAAABABQANAFAJAAQAIAAAFgDQAFgEAAgHQAAgJgOgGIgMgEQgUgIAAgPQAAgNAKgGQAJgHAMAAQANAAAMAGIACACIgBABIgCAHQAAAAAAAAQAAABgBAAQAAAAAAAAQgBAAAAAAIgCAAQgJgFgKAAQgHAAgEAEQgEADAAAFQAAAIAMAFIAOAHQASAGAAARQAAAMgJAJQgKAHgOAAQgNAAgNgGg");
	this.shape_14.setTransform(-42.9143,46.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAaAvQgDAAAAgEIAAg0QAAgMgEgFQgFgHgKABQgNAAgMALIAABAQAAAEgEAAIgJAAQgEAAAAgEIAAhTQAAgEAEAAIAIAAQAEAAAAAEIAAAFQAOgLAQAAQAfAAAAAiIAAA3QAAAEgEAAg");
	this.shape_15.setTransform(-51.225,46.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgjAiQgJgNAAgTQAAgWAMgOQALgNASAAQAPAAAJALIAAgFQAAgBAAgBQABgBAAAAQABgBAAAAQABAAABAAIAIAAQAEAAAAAEIAABBQAAAHABACQAAAAAAABQABAAAAAAQAAAAABAAQAAAAABAAIABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABIAAAGQAAABAAABQgBAAAAAAQAAABgBAAQAAAAgBAAIgIAAQgGAAgDgEQgDgEAAgGIgBAAQgDAGgIAFQgJAFgHAAQgTAAgKgOgAgUgYQgHAJAAAPQAAAQAHAJQAGAKAKgBQAIAAAHgFQAHgGADgIIAAgkQgEgFgGgEQgGgEgGAAQgMAAgHAKg");
	this.shape_16.setTransform(-60.875,46.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgSAvQgEAAAAgEIAAhTQAAgEAEAAIAIAAQAEAAAAAEIAAAGQAIgMANAAIAGABQAAAAABAAQAAAAAAABQABAAAAABQAAAAgBABIgBAIQAAABAAAAQAAABgBAAQAAAAAAAAQgBABAAAAIgGgBQgLAAgHAMIAAA/QAAAEgEAAg");
	this.shape_17.setTransform(63.905,24.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgcAiQgLgMAAgWQgBgUAMgNQANgOATAAQAQAAAKAKQALAMgBAUIAAADQAAABAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAQgBABgBAAIg5AAQAAANAIAJQAHAKANgBQANAAALgDQAAgBABAAQABAAAAAAQABABAAAAQAAAAAAABIACAHQABAAAAABQgBAAAAABQAAAAAAABQgBAAgBABQgMAFgQAAQgVAAgMgOgAgOgaQgHAHgBALIAuAAIAAgCQAAgLgEgGQgHgIgKAAQgKAAgHAJg");
	this.shape_18.setTransform(56.25,25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgEBEQgDAAAAgFIAAh9QAAAAAAgBQAAgBAAAAQABgBAAAAQABAAABgBIAJAAQABAAABAAQAAAAAAAAQABABAAAAQAAABAAAAIAAB/QAAAFgDAAg");
	this.shape_19.setTransform(49.875,22.85);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgEBEQgDAAAAgFIAAh9QAAgDADgBIAJAAQABAAABAAQAAAAABAAQAAABAAAAQAAABAAAAIAAB/QAAAFgDAAg");
	this.shape_20.setTransform(46.225,22.85);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgcAiQgMgMAAgWQAAgUANgNQALgOAUAAQAPAAAKAKQALAMAAAUIAAADQAAABAAABQAAAAAAAAQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAQgBABgBAAIg6AAQABANAHAJQAJAKANgBQAMAAAKgDQABgBABAAQABAAAAAAQABABAAAAQAAAAABABIACAHQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAABQgMAFgSAAQgUAAgMgOgAgPgaQgGAHgBALIAvAAIAAgCQgBgLgFgGQgFgIgLAAQgKAAgIAJg");
	this.shape_21.setTransform(40,25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgOAHQgDAAAAgDIAAgHQAAgBAAgBQAAAAAAAAQABgBAAAAQABAAABAAIAcAAQAEAAAAADIAAAGQAAAEgDAAg");
	this.shape_22.setTransform(29.2,24.625);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AggAiQgKgNAAgVQAAgUALgNQAMgOAUAAQAVAAALAOQAKAMAAAVQAAAVgLANQgMAOgUAAQgVAAgLgOgAgUgXQgFAJAAAOQAAAPAFAJQAHALANAAQANABAIgMQAGgJAAgPQAAgOgGgJQgHgMgOAAQgNAAgHAMg");
	this.shape_23.setTransform(22.025,25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAVBEQgEAAgCgDIgcgrIgEAEIAAAmQAAAEgEAAIgJAAQgDAAAAgEIAAh9QAAgDADgBIAKgCQADAAAAAEIAABMIAdgiQAAAAABgBQAAAAABgBQAAAAABAAQAAAAABAAIAMAAQAAAAABAAQAAAAAAAAQAAAAAAABQABAAAAAAIgBACIgdAhIAhAyQAEAFgGAAg");
	this.shape_24.setTransform(13.7431,22.825);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgcAqQgBAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBIACgGQAAgBABgBQAAAAABAAQAAgBAAAAQABAAABABQANAFAJAAQAIAAAFgDQAFgFAAgGQAAgJgOgGIgMgFQgUgGAAgQQAAgNAKgGQAJgHAMAAQANAAAMAGIACACIgBABIgCAHQAAAAAAAAQAAABgBAAQAAAAAAAAQgBABAAAAIgCgBQgJgFgKAAQgHAAgEAEQgEADAAAFQAAAIAMAFIAOAHQASAGAAAQQAAANgJAJQgKAHgOAAQgNAAgNgGg");
	this.shape_25.setTransform(5.8857,25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgjAiQgJgNAAgUQAAgVAMgOQALgNASAAQAPAAAJALIAAgFQAAgBAAgBQABgBAAAAQABgBAAAAQABAAABAAIAIAAQAEAAAAAEIAABBQAAAIABABQAAAAAAABQABAAAAAAQAAAAABAAQAAAAABAAIABAAQABAAAAABQABAAAAAAQAAAAABABQAAAAAAABIAAAGQAAABAAABQgBAAAAAAQAAABgBAAQAAAAgBAAIgIAAQgGAAgDgEQgDgEAAgGIgBAAQgDAGgIAFQgJAFgHAAQgTAAgKgOgAgUgZQgHAKAAAPQAAAQAHAJQAGAKAKgBQAIABAHgHQAHgFADgIIAAgjQgEgHgGgDQgGgEgGAAQgMAAgHAJg");
	this.shape_26.setTransform(-2.375,25);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAVBEQgEAAgCgDIgcgrIgEAEIAAAmQAAAEgEAAIgJAAQgDAAAAgEIAAh9QAAgDADgBIAKgCQADAAAAAEIAABMIAdgiQAAAAABgBQAAAAABgBQAAAAABAAQAAAAABAAIAMAAQAAAAABAAQAAAAAAAAQAAAAAAABQABAAAAAAIgBACIgdAhIAhAyQAEAFgGAAg");
	this.shape_27.setTransform(-10.7569,22.825);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAaAvQgDAAAAgEIAAg0QAAgMgEgFQgFgHgKAAQgNAAgMAMIAABAQAAAEgEAAIgJAAQgEAAAAgEIAAhTQAAgEAEAAIAIAAQAEAAAAAEIAAAFQAOgLAQAAQAfAAAAAiIAAA3QAAAEgEAAg");
	this.shape_28.setTransform(-23.925,24.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgDA+QgEAAAAgEIAAhTQAAgEAEAAIAIAAQADAAAAAEIAABTQAAAEgDAAgAgGgtQgDgCAAgEQAAgEADgDQADgDADAAQAEAAADADQADADAAAEQAAAEgEACQgCADgEAAQgDAAgDgDg");
	this.shape_29.setTransform(-30.8,23.425);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgfA2QgJgMAAgVQAAgVALgMQAMgPARAAQAQAAAJALIAAgvQAAAAAAgBQABgBAAAAQAAgBABAAQAAAAABgBIAKAAQABAAABAAQAAAAABAAQAAABAAAAQAAABAAAAIAAB/QAAAFgDAAIgIAAQgEgBAAgDIAAgHQgKAMgRAAQgTAAgLgOgAgQgEQgHAJAAAQQAAAPAGAKQAHAJALABQAHAAAHgFQAGgDAEgFIAAgsQgDgFgGgEQgHgDgGAAQgMAAgHAJg");
	this.shape_30.setTransform(-37.875,22.95);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgjA5QgJgNAAgUQAAgWAMgNQALgOASAAQAPAAAJAMIAAgGQAAgBAAgBQABAAAAgBQABAAAAAAQABAAABAAIAIAAQAEAAAAADIAABCQAAAHABABQAAABAAAAQABAAAAABQAAAAABAAQAAAAABAAIABAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAABIAAAGQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAIgIAAQgGAAgDgFQgDgDAAgHIgBAAQgDAHgIAFQgJAEgHAAQgTABgKgOgAgUgCQgHAJAAAQQAAAPAHAKQAGAJAKAAQAIAAAHgGQAHgFADgJIAAgkQgEgFgGgEQgGgDgGAAQgMAAgHAJgAgOgmQgGgGAAgIQAAgHAGgGQAFgEAHgBQAHABAGAEQAFAGAAAHQAAAIgFAGQgGAEgHAAQgHAAgFgEgAgIg5QgCACAAADQAAAEACADQADACADAAQADAAADgCQACgDAAgEQAAgDgCgCQgDgDgDgBQgDABgDADg");
	this.shape_31.setTransform(-51.175,22.75);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AglBDQgDAAAAgEIAAh8QAAgBAAgBQAAAAABgBQAAAAABAAQAAAAABAAIAIAAQAEgBAAAEIAAAHQAFgFAHgEQAIgEAHAAQATAAALAPQAJANAAAUQAAATgKANQgLAQgUgBQgPAAgJgKIAAAtQAAAEgEAAgAgOgyQgGADgEAGIAAArQADAGAGAEQAHAEAHAAQAMAAAHgMQAGgJAAgOQAAgOgFgKQgGgLgNABQgHAAgHADg");
	this.shape_32.setTransform(-60.675,26.95);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgJALQgFgFAAgGQAAgGAFgEQAEgDAFAAQAGAAAFADQAEAEAAAGQAAAGgEAEQgFAFgGAAQgFgBgEgDg");
	this.shape_33.setTransform(46.525,5.65);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgXAvQgFAAAAgFIAAhRQAAgFAFAAIAQAAQAFAAAAAEIAAAGQAFgHAFgCQAFgDAIAAIAGAAQABAAAAAAQAAABABAAQAAABAAABQAAAAAAABIgDASQAAABAAABQgBAAAAABQAAAAgBAAQAAAAgBAAIgGAAQgKAAgHAHIAAA4QAAAFgFAAg");
	this.shape_34.setTransform(41.8042,2.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AARBEQgGAAgDgEIgUgmIAAAAIAAAlQgBAFgEAAIgTAAQgFAAAAgFIAAh6QAAgFAFgBIATgCQAEAAABAFIAABLIAAAAIAUghQACgDAEAAIAVAAQAAAAABAAQABAAAAAAQABABAAAAQAAABAAAAIgBADIgZAhIAdAvIABAEQAAAAAAABQgBAAAAABQgBAAAAAAQgBAAgBAAg");
	this.shape_35.setTransform(33.8,0.025);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgkAyQgMgSAAgfQAAgeANgTQANgTAXAAQAYgBAMAUQAMARAAAfQAAAfgMATQgMASgZABQgXAAgNgTgAgRAAQAAAXAFAKQAEAKAIAAQAKAAADgKQAFgKAAgXQAAgpgRAAQgSAAAAApg");
	this.shape_36.setTransform(19.475,0.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgkAyQgMgSAAgfQAAgeANgTQANgTAXAAQAYgBAMAUQAMARAAAfQAAAfgMATQgMASgZABQgXAAgNgTgAgRAAQAAAXAFAKQAEAKAIAAQAKAAADgKQAFgKAAgXQAAgpgRAAQgSAAAAApg");
	this.shape_37.setTransform(9.175,0.25);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgkAyQgMgSAAgfQAAgeANgTQANgTAXAAQAYgBAMAUQAMARAAAfQAAAfgMATQgMASgZABQgXAAgNgTgAgRAAQAAAXAFAKQAEAKAIAAQAKAAADgKQAFgKAAgXQAAgpgRAAQgSAAAAApg");
	this.shape_38.setTransform(-1.125,0.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgJALQgFgFAAgGQAAgGAFgEQAEgDAFAAQAGAAAFADQAEAEAAAGQAAAGgEAEQgFAFgGAAQgFgBgEgDg");
	this.shape_39.setTransform(-8.175,5.65);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAYBCQgHAAAAgGIAAgVIg5AAQgGAAAAgHIAAgJQAAgFACgGIAkhHQADgGAFAAIAPAAQAGAAAAAEIgBAEIgiBHIAfAAIAAgbQAAgHAHAAIARAAQAGAAAAAHIAABJQAAAGgGAAg");
	this.shape_40.setTransform(-15.725,0.25);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgIBEQgFAAAAgFIAAh7QAAgEAEgBIATgCQAEAAAAAEIAAB9QAAAGgFAAg");
	this.shape_41.setTransform(-26.925,0.05);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgHBCQgGAAAAgFIAAhRQAAgFAGAAIAQAAQAFAAAAAFIAABRQAAAFgFAAgAgJgoQgFgEAAgHQAAgGAEgEQAFgEAFAAQAGAAAEAEQAFAEAAAGQAAAHgFAEQgEAEgGAAQgFAAgEgEg");
	this.shape_42.setTransform(-31.625,0.225);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgPA0QgFgFgBgHIgBgSIAAgkIgHAAQgBAAgBAAQAAAAgBAAQAAAAgBAAQAAgBAAAAQgBgBAAgEIAAgIQgBgFAFAAIAIAAIAAgUQAAgEAHgBIARgCQAEAAAAAEIAAAXIAVAAQAEAAAAAEIAAALQAAAEgEAAIgVAAIAAAkQAAAJACADQACAEAFABQAFgBAIgCIACAAQABAAAAAAQABAAAAAAQAAAAABABQAAAAAAABIADAMIAAACQAAACgEACQgKAFgNAAQgRAAgHgJg");
	this.shape_43.setTransform(-37.6,1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgoBEQgFAAAAgFIAAh6QAAgGAGAAIAOAAQAGAAAAAFIABADQADgEAHgDQAHgDAHAAQAQAAALALQANANAAAXQAAAXgNANQgLAOgSAAQgMAAgIgIIAAApQAAAFgGAAgAgQglIAAAmQAGAGAJAAQAHAAAEgGQAGgHAAgMQAAgNgFgGQgEgHgIAAQgJAAgGAHg");
	this.shape_44.setTransform(-50.175,4.15);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgjAjQgMgNAAgWQAAgVANgNQANgOAVAAQAYAAAMAOQAMANAAAVQAAAWgNANQgNAOgWAAQgXAAgMgOgAgSAAQABAaARAAQASAAAAgaQAAgZgSAAQgRAAgBAZg");
	this.shape_45.setTransform(-60.7,2.225);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAUAvQgFAAAAgFIAAgxQAAgOgKAAQgKAAgJAHIAAA4QAAAFgFAAIgSAAQgFABgBgGIAAhRQAAgFAGAAIAQAAQAFAAAAAEIAAAEQAOgLAQAAQAdAAAAAiIAAA3QAAAFgFAAg");
	this.shape_46.setTransform(111.75,-19.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgfAkQgNgOAAgWQAAgVAOgNQANgOAVAAQASAAAMANQALAMAAAXIAAACQAAAGgGAAIg1AAQACAIAHAFQAGAGAJAAQAMAAALgGIADAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAIADAPQABACgEADQgOAGgVAAQgVAAgOgNgAASgJQgBgHgEgFQgEgFgGAAQgGAAgFAFQgEAEgCAIIAgAAIAAAAg");
	this.shape_47.setTransform(101.8,-19.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgjAjQgMgNAAgWQAAgVANgNQANgOAVAAQAYAAAMAOQAMANAAAVQAAAWgNANQgNAOgWAAQgXAAgMgOgAgSAAQABAaARAAQATAAgBgaQABgZgTAAQgRAAgBAZg");
	this.shape_48.setTransform(91.95,-19.475);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AARBEQgHAAgCgEIgUgmIgBAAIAAAlQAAAFgEAAIgTAAQgFAAAAgFIAAh6QAAgFAFgBIAUgCQADAAAAAFIAABLIABAAIAUghQACgDAEAAIAVAAQAAAAABAAQABAAAAAAQABABAAAAQAAABAAAAIgBADIgZAhIAcAvIACAEQAAAAAAABQAAAAgBABQAAAAgBAAQgBAAgBAAg");
	this.shape_49.setTransform(82.65,-21.675);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgHBCQgGAAAAgFIAAhRQAAgFAGAAIAQAAQAFAAAAAFIAABRQAAAFgFAAgAgJgoQgFgEAAgHQAAgGAEgEQAFgEAFAAQAGAAAEAEQAFAEAAAGQAAAHgFAEQgEAEgGAAQgFAAgEgEg");
	this.shape_50.setTransform(75.175,-21.475);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AghAqQAAAAgBgBQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAgCIAEgMQAAgBAAgBQABAAAAAAQAAgBABAAQAAAAABAAIADAAQAOAGALAAQAJAAAAgGQAAgFgJgEIgQgGQgIgDgFgFQgGgIAAgJQAAgPAMgHQAKgHANAAQAQAAAOAGQAAAAABABQABAAAAAAQAAABABAAQAAABAAAAIgBACIgEAOQAAAAAAABQAAAAgBABQAAAAgBAAQAAAAgBAAIgCAAQgMgFgJAAQgEAAgCACQgBABAAAAQgBAAAAABQAAAAAAABQAAABAAAAQAAAFAGACIATAIQARAGAAASQAAAPgMAIQgKAHgPAAQgPAAgRgHg");
	this.shape_51.setTransform(68.975,-19.475);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgHBCQgGAAAAgFIAAhRQAAgFAGAAIAQAAQAFAAAAAFIAABRQAAAFgFAAgAgJgoQgFgEAAgHQAAgGAEgEQAFgEAFAAQAGAAAEAEQAFAEAAAGQAAAHgFAEQgEAEgGAAQgFAAgEgEg");
	this.shape_52.setTransform(62.775,-21.475);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgXAvQgFAAAAgFIAAhRQAAgFAFAAIAQAAQAFAAAAAEIAAAGQAFgHAFgCQAFgDAIgBIAGABQABAAAAAAQAAABABAAQAAABAAABQAAABAAAAIgDASQAAABAAABQgBAAAAABQAAAAgBAAQAAAAgBAAIgGAAQgKAAgHAHIAAA4QAAAFgFAAg");
	this.shape_53.setTransform(57.6542,-19.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgFAuQgFAAgBgEIgihTIgBgCQAAAAABgBQAAAAAAgBQABAAABAAQAAAAABAAIAWAAQAFAAABAEIAMAnIADANIAEgNIANgnQACgEAFAAIARAAQAFAAAAADIgBACIgiBSQgCAEgEAAg");
	this.shape_54.setTransform(49.275,-19.475);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgIBEQgFAAAAgFIAAh7QAAgEAEgBIATgCQAEAAAAAFIAAB9QAAAFgFAAg");
	this.shape_55.setTransform(42.425,-21.65);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgfAkQgNgOAAgWQAAgVAOgNQAOgOAUAAQATAAALANQALAMAAAXIAAACQAAAGgHAAIg0AAQACAIAHAFQAFAGAKAAQAMAAAMgGIACAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAIAEAPQAAACgEADQgOAGgVAAQgVAAgOgNgAASgJQAAgHgFgFQgDgFgIAAQgFAAgFAFQgFAEgBAIIAgAAIAAAAg");
	this.shape_56.setTransform(35.4,-19.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AghAqQAAAAgBgBQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAgCIAEgMQAAgBAAgBQABAAAAAAQAAgBABAAQAAAAABAAIADAAQAOAGALAAQAJAAAAgGQAAgFgJgEIgQgGQgIgDgFgFQgGgIAAgJQAAgPAMgHQAKgHANAAQAQAAAOAGQAAAAABABQABAAAAAAQAAABABAAQAAABAAAAIgBACIgEAOQAAAAAAABQAAAAgBABQAAAAgBAAQAAAAgBAAIgCAAQgMgFgJAAQgEAAgCACQgBABAAAAQgBAAAAABQAAAAAAABQAAABAAAAQAAAFAGACIATAIQARAGAAASQAAAPgMAIQgKAHgPAAQgPAAgRgHg");
	this.shape_57.setTransform(26.825,-19.475);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgPA0QgEgEgCgIIAAgSIAAgjIgIAAQgBAAgBgBQAAAAgBAAQAAAAgBAAQAAgBAAAAQgBgBAAgEIAAgIQgBgFAFAAIAJAAIAAgUQgBgFAHAAIARgCQAEAAAAAEIAAAXIAUAAQAGAAgBAEIAAALQABAEgGABIgUAAIAAAjQAAAJABADQADAEAFABQAFgBAIgCIADgBQAAAAAAABQABAAAAAAQAAAAABABQAAAAAAABIACAMIAAACQAAABAAAAQAAABAAAAQgBABAAAAQgBABgBAAQgLAFgNAAQgQAAgHgJg");
	this.shape_58.setTransform(15.3,-20.7);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgeAkQgOgOAAgWQAAgVAOgNQANgOAWAAQARAAAMANQALAMAAAXIAAACQAAAGgGAAIg1AAQACAIAHAFQAGAGAIAAQAMAAAMgGIADAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAIAEAPQgBACgDADQgPAGgTAAQgWAAgNgNgAARgJQAAgHgDgFQgFgFgGAAQgGAAgFAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_59.setTransform(7,-19.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AAQBEQgFAAgDgEIgUgmIAAAAIAAAlQAAAFgGAAIgSAAQgFAAAAgFIAAh6QAAgFAEgBIAUgCQAFAAAAAFIAABLIAAAAIAUghQACgDAEAAIAUAAQABAAABAAQABAAAAAAQABABAAAAQAAABAAAAIgBADIgYAhIAcAvIABAEQAAAAAAABQgBAAAAABQgBAAAAAAQgBAAgBAAg");
	this.shape_60.setTransform(-2,-21.675);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AARBEQgGAAgDgEIgUgmIgBAAIAAAlQAAAFgEAAIgTAAQgFAAAAgFIAAh6QAAgFAFgBIATgCQAEAAAAAFIAABLIABAAIAUghQACgDAEAAIAVAAQAAAAABAAQABAAAAAAQABABAAAAQAAABAAAAIgBADIgZAhIAcAvIACAEQAAAAAAABQgBAAAAABQAAAAgBAAQgBAAgBAAg");
	this.shape_61.setTransform(-11.3,-21.675);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgCAlQgRAMgVAAQgNAAgIgIQgJgHAAgOQAAgRARgIQAOgHAXAAIAAgEQAAgEgDgDQgEgDgHAAQgNAAgMAGIgCABQAAAAgBgBQAAAAAAAAQgBgBAAAAQgBgBAAgBIgDgLIgBgBQAAgDAEgCQAPgIATAAQAUAAAGAMQALgMATAAQAbAAAKAZQAEAKAAANQAAAEgCACQgBACgEAAIg1AAQACAIAHAFQAGAGAJAAQAMAAAMgGIADAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAIADAPQAAACgDADQgPAGgUAAQgVAAgLgMgAgiAJQgHADAAAGQAAAJAKAAIAKgCIAIgEQgDgGAAgGIAAgDQgLAAgHADgAArgJQAAgHgDgFQgEgFgIAAQgGAAgFAFQgFAEgBAIIAgAAIAAAAg");
	this.shape_62.setTransform(-23.675,-19.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgiA3QgLgMAAgUQAAgVALgNQALgRAUABQAMAAAIAHIAAgoQAAgFAFgBIAUgDQAEAAAAAFIAAB+QAAAFgFAAIgQAAQgFAAAAgEIgBgEQgDAEgHADQgHAEgGAAQgTgBgLgOgAgLADQgEAIAAAJQAAAaARAAQAJABAGgIIAAgnQgGgEgJgBQgIABgFAHg");
	this.shape_63.setTransform(-36.325,-21.55);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgoA8QgJgMAAgUQAAgZANgNQAMgMAQAAQAQAAAHAKIABgDQAAgFADAAIASAAQAFABAAAEIAABAQAAABAAABQAAABAAAAQAAABABAAQAAAAABAAIACAAQAEAAAAAEIAAAKQAAAFgFAAIgKAAQgOAAgEgIIAAAAQgFAEgHADQgHADgHABQgTgBgMgOgAgOAGQgGAHABAMQAAAaARAAQADAAAGgCIAGgGIAAgkQgIgHgGABQgIAAgFAFgAgQgkQgHgHAAgIQAAgJAHgHQAGgGAKgBQAIABAHAGQAFAHAAAJQAAAIgFAHQgHAGgIAAQgKAAgGgGgAgGg5QgCACAAAEQAAACACACQADACADAAQACAAACgCQACgCAAgCQAAgEgCgCQgCgCgCAAQgDAAgDACg");
	this.shape_64.setTransform(-50.45,-22.05);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgkBCQgGAAAAgGIAAh4QAAgFAFAAIBLAAQAFAAgBAEIgBAQQgBAFgHAAIgtAAIAAAcIAqAAQAGAAAAAFIAAANQAAAGgFgBIgrAAIAAAyQAAAFgFAAg");
	this.shape_65.setTransform(-60.4477,-21.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-68,-34.3,231.6,91.8);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.pris();
	this.instance.parent = this;
	this.instance.setTransform(-112,-57,1.1461,1.1461);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112,-57,183.4,114.6);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAKApIgEgEIgBgDQAAgCACgDQANgNAAgJQAAgEgGgJQgHgJAAgGQAAgKAHgGQAGgGAKAAQALAAAHAIQAGAJAAAKQAAAighAYQgEACgCAAQgCAAgDgDgAgwApIgEgEIgBgDQAAgCACgDQANgNAAgJQAAgEgGgJQgHgJAAgGQAAgKAHgGQAHgGAJAAQALAAAHAIQAHAJAAAKQAAAigiAYQgEACgCAAQgCAAgDgDg");
	this.shape.setTransform(-93.825,4.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAQQgJgGAAgKQABgJAHgGQAGgGAJAAQAJAAAHAGQAHAGAAAJQAAAKgHAGQgHAGgJAAQgIAAgGgGg");
	this.shape_1.setTransform(-103.85,18.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPAQQgIgGAAgKQABgJAHgGQAHgGAIAAQAKAAAGAGQAIAGgBAJQABAKgIAGQgHAGgJAAQgIAAgHgGg");
	this.shape_2.setTransform(-110.5,18.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgPAQQgHgGgBgKQAAgJAIgGQAHgGAIAAQAKAAAGAGQAIAGgBAJQABAKgIAGQgHAGgJAAQgIAAgHgGg");
	this.shape_3.setTransform(-117.15,18.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgyBAQgFgCABgDIAAgEIAGgSQACgFADAAIAEABQAWAJARAAQAOAAAAgKQAAgIgNgFIgZgJQgNgFgIgJQgJgLAAgPQAAgWASgLQAPgLAWAAQAZAAAUAKQAEACAAADIgBADIgGAUQgBAEgEAAIgDgBQgSgHgOAAQgGAAgDADQgEADAAADQAAAHAKAEIAdAMQAbAJAAAbQAAAYgTAMQgPALgYAAQgXAAgZgLg");
	this.shape_4.setTransform(-133.9,12.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag9BoQgIAAAAgJIAAi6QAAgIAJAAIAWAAQAIAAABAGIABAGQAFgHALgEQALgFAKAAQAZAAARARQATAUAAAjQAAAigTAWQgRAUgcABQgTAAgMgMIAAA9QAAAJgJAAgAgZg5IAAA6QAJAKAOAAQALgBAHgJQAIgKAAgUQAAgSgGgKQgHgLgNAAQgOAAgJALg");
	this.shape_5.setTransform(-147.925,15.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhBAVIAAhVQgBgHAKgBIAaAAQAIABAAAHIAABNQAAAVAQAAQAQAAANgMIAAhWQAAgHAJgBIAaAAQAJABAAAHIAAB7QgBAKgIAAIgYAAQgHgBgBgFIgBgHQgUARgZgBQgtABAAg0g");
	this.shape_6.setTransform(-165,13.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhCAVIAAhVQABgHAIgBIAaAAQAJABAAAHIAABNQAAAVARAAQAPAAANgMIAAhWQAAgHAJgBIAaAAQAIABAAAHIAAB7QABAKgKAAIgXAAQgIgBAAgFIgBgHQgUARgZgBQguABAAg0g");
	this.shape_7.setTransform(-181.7,13.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhBAVIAAhVQAAgHAJgBIAaAAQAIABAAAHIAABNQAAAVAQAAQAQAAANgMIAAhWQAAgHAJgBIAaAAQAJABgBAHIAAB7QAAAKgJAAIgXAAQgIgBAAgFIAAgHQgVARgZgBQgtABAAg0g");
	this.shape_8.setTransform(-198.4,13.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhXAJIAAhnQAAgIAJAAIAdAAQAJAAAAAIIAABjQgBAgALAOQAKAMAVABQAVAAAJgNQALgOAAggIAAhjQAAgIAIAAIAdAAQAJAAAAAIIAABmQAABehYAAQhXABAAheg");
	this.shape_9.setTransform(-217.45,10.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AALAjQgGgIAAgLQgBghAjgYQADgDACAAQACAAADAEIADAEIACAEQAAAAAAAAQAAABAAAAQAAABgBAAQAAABgBAAQgNAOAAAJQgBAEAHAIQAHAKAAAGQAAAKgHAGQgHAGgJAAQgKABgIgKgAgvAjQgHgIAAgLQABghAhgYQADgDADAAQACAAADAEIAEAEIACAEQAAAAgBAAQAAABAAAAQAAABgBAAQAAABgBAAQgOAOAAAJQAAAEAIAIQAGAKAAAGQAAAKgHAGQgHAGgJAAQgLABgHgKg");
	this.shape_10.setTransform(-235,3.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-244,-8.7,159.4,37.099999999999994);


// stage content:
(lib._300x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// price
	this.instance = new lib.Tween5("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-69,280.75,1.1042,1.1042);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:131},6).to({scaleX:0.9027,x:140.65},9).to({scaleX:1.1042,x:131},6).to({startPosition:0},21).to({startPosition:0},77).wait(1));

	// button
	this.instance_1 = new lib.Tween9("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-70.1,521.05,1.03,1.03,0,0,0,-0.1,0.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(25).to({_off:false},0).to({x:79.5},10).to({startPosition:0},84).wait(1));

	// text2
	this.instance_2 = new lib.Tween7("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-159.45,429.3);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(21).to({_off:false},0).to({x:86.15},6).to({startPosition:0},58).to({startPosition:0},34).wait(1));

	// ups
	this.instance_3 = new lib.Tween1("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(76.7,57.25);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:280.2,y:63.75},17).to({startPosition:0},102).wait(1));

	// background
	this.instance_4 = new lib.Q8_LowRisQ_Privat160x600_Q8_LowRisQ_Privat();
	this.instance_4.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(120));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.5,300,377.5,300);
// library properties:
lib.properties = {
	id: 'B7160C9E680A4044993FEE0D188B75E6',
	width: 300,
	height: 600,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/300x600_atlas_P_.png", id:"300x600_atlas_P_"},
		{src:"images/300x600_atlas_P_2.png", id:"300x600_atlas_P_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['B7160C9E680A4044993FEE0D188B75E6'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;